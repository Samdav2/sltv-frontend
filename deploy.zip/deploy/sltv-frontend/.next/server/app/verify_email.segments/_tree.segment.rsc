:HL["/_next/static/chunks/1ea2bfe91bbff8b3.css","style"]
:HL["/_next/static/media/5d52bd6c4cb3f315-s.p.610fd2a3.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"buildId":"_eSVjkSP76zpJyEoI5_zv","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"verify_email","paramType":null,"paramKey":"verify_email","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
